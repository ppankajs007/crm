<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class App extends CI_Model
{

	private static $db;

	function __construct(){
		parent::__construct();
		self::$db = &get_instance()->db;
	}


	/**
	* Counts num of records in TABLE
	*/

	static function counter($table,$where = array()) {

		return self::$db->where($where)->get($table)->num_rows();
	}

	// Get activities
	static function get_activity($limit = NULL) {
		return self::$db->order_by('activity_date','desc')->get('activities',$limit)->result();
	}



  	/**
	* Insert data to logs table
	*/
	static function Log($data = array()) {
		return self::$db->insert('activities',$data);
	}


	

	static function get_by_where($table, $array = NULL, $order_by = array()){
		if(count($order_by) > 0) { self::$db->order_by($order_by['column'],$order_by['order']) ; }
    	return self::$db->where($array)->get($table)->result();
	}


	static function get_row_by_where($table, $array = NULL, $order_by = array()){
		if(count($order_by) > 0) { self::$db->order_by($order_by['column'],$order_by['order']) ; }
    	return self::$db->where($array)->get($table)->row();
	}
	

	

	// Save any data
	static function save_data($table, $data){
		self::$db->insert($table,$data);
		return self::$db->insert_id();
	}

	/**
	* Update records in $table matching $match.
	*
	* @return Affected rows int
	*/

	static function update($table,$match = array(),$data = array()) {

		self::$db->where($match)->update($table,$data);
		return self::$db->affected_rows();
	}

	/**
	* Deletes data matching $where in $table.
	*
	* @return boolean
	*/

	static function delete($table,$where = array()) {

		return self::$db->delete($table,$where);
	}

	

}

/* End of file model.php */