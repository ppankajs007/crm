        <style>
.tooltip {
  position: relative;
  display: inline-block;
  border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: black;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px 0;
  position: absolute;
  z-index: 1;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
}
</style>
        <div class="container-fluid">                       
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                             <li class="breadcrumb-item"><a href="<?php echo base_url();?>">CRM</a></li>
                                            <li class="breadcrumb-item active">Qualified Leads</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Qualified Leads</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                      <div class="row mb-2">
                                            <div class="col-sm-4">
                                                <!--<a href="<?php echo base_url();?>crm/leads/add" class="btn btn-danger waves-effect waves-light" data-animation="fadein" data-plugin="custommodal" data-overlaycolor="#38414a" id="modal_disable"><i class="mdi mdi-plus-circle mr-1"></i> Add New Lead</a>-->
                                            </div>
                                            <div class="col-sm-8">
                                                <div class="text-sm-right">
                                                    <button type="button" class="btn btn-success mb-2 mr-1"><i class="mdi mdi-settings"></i></button>
                                                    <button type="button" class="btn btn-light mb-2 mr-1">Import</button>
                                                    <button type="button" class="btn btn-light mb-2">Export</button>
                                                </div>
                                            </div><!-- end col-->
                                        </div>
                                        <table id="qualifiedleadsTable" class="table" style="width:100%"> 
                                           <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Status</th>
                                                    <th>Original Designer</th>
                                                    <th>Designer Assigned</th>
                                                    <th>Survey</th>
                                                    <th>Hotness</th>
                                                    <th>Date Received</th>
                                                    <th>Date Added</th>
                                                    <th>Date Started</th>
                                                    <th>Date Completed</th>
                                                    <th>Queue time</th>
                                                    <th>Date Sent</th>
                                                    <!--<th>Cabinet Manufacturer</th>-->
                                                    <!--<th>Cabinet Style</th>-->
                                                    <!--<th>Counters</th>-->
                                                    <!--<th>Handles</th>-->
                                                    <!--<th>Backsplash</th>-->
                                                    <th>Action</th> 
                                                </tr>
                                            </thead>
                                            <tfoot>
                                               
                                            </tfoot>
                                        </table>

                                    </div> <!-- end card body -->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div>
                        <!-- end row-->
        </div> <!-- container -->