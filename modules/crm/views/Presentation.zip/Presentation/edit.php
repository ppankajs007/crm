  <style>
  	.error {
    display: none;
    width: 100%;
    margin-top: .25rem;
    font-size: .75rem;
    color: #f1556c;
    display: block;
}
  </style>
  
  
  
        
    <div class="content-pageee">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-md-12">
                                
                                 <?php 
  //pr($leads); die();
  //pr($users); die();
  //pr($KitFilesF);
 
 
 
             if( empty($leads) ) return;
                extract($leads);
              $fullname= @$first_name.''.@$last_name;  


               ?>
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">CRM</a></li>
                                            <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>crm/Qualified">Qualified</a></li>
                                             <li class="breadcrumb-item"><a href="<?php echo base_url();?>crm/Qualified/dashboard/<?php echo $id; ?>">Dashboard</a></li>
                                            <li class="breadcrumb-item active">
                                            <?php  if( empty($leads) ) return;
                                                    extract($leads);
                                                  $fullname = @$first_name.''.@$last_name;
                                                  echo $fullname;
                                            ?>
                                                
                                                
                                            </li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Edit Qualified Lead</h4>
                                </div>
                            </div>
                        </div>  
                          <div class="row">
                            <div class="col-md-12">   
                                 <div class="card">
                                  <div class="card-body">

 
         
        <?php $attr = array( 'id' => 'QualifiedEform'); echo form_open($this->uri->uri_string(),$attr); ?>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group ">
                <label for="">Full Name</label>
                 <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
                <input type="text" class="form-control" name="name" value="<?php echo $fullname;?>" placeholder="Enter full name" >
                <div class="invalid-feedback"></div>
            </div>          
          </div>
        
          <div class="col-md-6">
            <div class="form-group">
                <label for="">Status</label>
                <?php $qfStatus = array('Not Started','Started','Q/C Check','Revision Required','Revision Completed','Approved for Deck','Completed','Sent to Customer') ?>
                <select  class="form-control" id="qf_status" name="qf_status" data-toggle="select2">
                    <?php foreach($qfStatus as $value){ ?>
                    <option class="" value="<?php echo $value ;?>" <?php if( $leads['qf_status'] == $value ){ echo  'selected="selected"'; } ?> ids="<?php echo $value; ?>" ><?php echo $value; ?></option>
                    <?php } ?>
                    
                </select>
             </div>
           </div>
           
            
          <!--<div class="col-md-12" id="lost_id" style="" >-->
          <!--  <div class="form-group ">-->
          <!--      <label for="">lost sale Reason</label>-->
                
          <!--      <input type="text" class="form-control" id="lost" name="lost_sale_detail" value="<?php// echo $leads['lost_sale_detail']; ?> " placeholder="Enter lost sale" >-->
          <!--      <div class="invalid-feedback"></div>-->
          <!--  </div>          -->
          <!--</div>-->
         
      
           <div class="col-md-6">
                     <div class="form-group">
                         <label for="">Designer Assigned</label>
                        <select  class="form-control" id="qf_designAssigned" name="qf_designAssigned" data-toggle="select2">
                            <option>Select Designer Assigned</option>
                        	<?php 
                          foreach ($users as $us)
                        { 
                         ?> 
                                <option value="<?php echo $us['name'];?>" <?php echo (($us['name']==$leads['qf_designAssigned'])?"selected":""); ?> id="0"><?php  echo $us['name'];?></option>
                                <?php }?>
                         </select>
                    </div>
              </div>
         
            <div class="col-md-6">
                <div class="form-group">
                    <?php if($leads['qf_dateRecieved'] != ''){
                    
                    
                       $new_date1 = strtotime($leads['qf_dateRecieved']);
                         $qf_dateRecieved = date('m/d/Y', $new_date1);
                    }?>
                  <label for="">Date Received</label>
                 
                  <input type="text" class="form-control" name="qf_dateRecieved" value="<?php  echo $qf_dateRecieved; ?>" id="dateMasksnd" >
                </div>
            </div>
        
          <div class="col-md-6">     
               <div class="form-group">
                  <label for="">Date Added</label>
                  <?php if($leads['qf_dateAdded'] != ''){
                    
                    
                       $new_date1 = strtotime($leads['qf_dateAdded']);
                         $qf_dateAdded = date('m/d/Y', $new_date1);
                    }else {
                    
                    $qf_dateAdded= "N/A"; 
                    
                    }?>
                  <input type="text" class="form-control" value="<?php echo  $qf_dateAdded; ?>" name="qf_dateAdded"  id="qf_dateAdded" readonly >
              </div>
          </div>
        
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">Date Started</label>
                     <?php if($leads['qf_datestarted'] != ''){
                    
                    
                       $new_date1 = strtotime($leads['qf_datestarted']);
                         $qf_datestarted = date('m/d/Y', $new_date1);
                    }else {
                    
                    $qf_datestarted= "N/A"; 
                    
                    }?>
                  <input type="text" class="form-control" name="qf_datestarted " value="<?php echo $qf_datestarted; ?>" id="qf_datestarted" readonly >
              </div> 
           </div>
         
           <div class="col-md-6">
              <div class="form-group">
                  
                   <?php if($leads['qf_dateCompleted'] != ''){
                    
                    
                       $new_date1 = strtotime($leads['qf_dateCompleted']);
                         $qf_dateCompleted = date('m/d/Y', $new_date1);
                    }else {
                    
                    $qf_dateCompleted= "N/A"; 
                    
                    }?>
                    <label for="">Date Completed </label>
                 
                  <input type="text" class="form-control" name="qf_dateCompleted" value="<?php  echo $qf_dateCompleted; ?>" id="qf_dateCompleted" readonly  >
              </div> 
           </div>
         
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">Date Sent</label>
                    <?php if($leads['qf_dateSent'] != ''){
                    
                    
                       $new_datesent = strtotime($leads['qf_dateSent']);
                         $qf_datesent = date('m/d/Y', $new_datesent);
                    }else {
                    
                    $qf_datesent= "N/A"; 
                    
                    }?>
                  <input type="text" class="form-control" name="qf_dateSent" value="<?php echo $qf_datesent; ?>" id="qf_dateSent" readonly >
              </div> 
           </div>

         
         <!-- other fileds start  -->
         
         
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">Kit File 1</label>
                  <input type="text" class="form-control" name="qf_Kit_File_1" value="<?php if( !empty( $KitFilesF[0]['file_name'] ) ){ echo base_url().'assets/'.$KitFilesF[0]["file_name"];   } ?>" id="qf_Kit_File_1" readonly >
              </div> 
           </div>
         
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">Kit File 2</label>
                  <input type="text" class="form-control" name="qf_Kit_File_2" value="<?php if( !empty( $KitFilesF[1]['file_name'] ) ){ echo base_url().'assets/'.$KitFilesF[1]["file_name"];   } ?>" id="qf_Kit_File_2" >
              </div> 
           </div>
        
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">Panoramic D1</label>
                  <input type="text" class="form-control" name="qf_Panoramic_D1" value="<?php if( !empty( $leads['qf_Panoramic_D1'] ) ){ echo $leads['qf_Panoramic_D1'];  }?>" id="qf_Panoramic_D1" >
              </div> 
           </div>
         
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">Panoramic D2</label>
                  <input type="text" class="form-control" name="qf_Panoramic_D2" value="<?php if( !empty( $leads['qf_Panoramic_D2'] ) ){ echo $leads['qf_Panoramic_D2'];  }?>" id="qf_Panoramic_D2" >
              </div> 
           </div>
         
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">Deck</label>
                  <input type="text" class="form-control" name="qf_Deck" value="<?php if( !empty( $leads['qf_Deck'] ) ){ echo $leads['qf_Deck'];  } ?>" id="qf_Deck">
              </div> 
           </div>
         
           <div class="col-md-6">
              <div class="form-group">
                  <?php if($leads['qf_LIVE_PRESENTATION_DATE'] != ''){
                       $new_live = strtotime($leads['qf_LIVE_PRESENTATION_DATE']);
                         $qf_live = date('m/d/Y', $new_live);
                    }else {
                    
                    $qf_live= "N/A"; 
                    
                    }?>
                    <label for="">LIVE PRESENTATION DATE</label>
                  <input type="text" class="form-control" name="qf_LIVE_PRESENTATION_DATE" value="<?php if( !empty( $leads['qf_LIVE_PRESENTATION_DATE'] ) ){ echo $qf_live;  }?>" id="dateMaskfst" placeholder="mm/dd/yyyy">
              </div> 
           </div>
       
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">LIVE PRESENTATION TIME</label>
                  <input type="text" class="form-control" name="qf_LIVE_PRESENTATION_TIME" value="<?php if( !empty( $leads['qf_LIVE_PRESENTATION_TIME'] ) ){ echo $leads['qf_LIVE_PRESENTATION_TIME'];  }?>" id="qf_LIVE_PRESENTATION_TIME">
              </div> 
           </div>
         
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">Qualifying Promotions</label>
                  <input type="text" class="form-control" name="qf_Qualifying_Promotions" value="<?php if( !empty( $leads['qf_Qualifying_Promotions'] ) ){ echo $leads['qf_Qualifying_Promotions'];  }?>" id="qf_Qualifying_Promotions">
              </div> 
           </div>
           
           <div class="col-md-6">
              <div class="form-group">
                    <label for="">Notes for Nicarter</label>
                  <input type="text" class="form-control" name="qf_Notes_for_Nicarter" value="<?php if( !empty( $leads['qf_Notes_for_Nicarter'] ) ){ echo $leads['qf_Notes_for_Nicarter'];  }?>" id="qf_Notes_for_Nicarter">
              </div> 
           </div>
      <div class="col-md-6">
            <div class="form-group">
                <label for="">Lead Status</label>
               
                <select  class="form-control" id="lead_status" name="lead_status" data-toggle="select2">
                      <option value="">Select option</option>
                     <?php 
                         foreach ($lead_statuss as $st) {
                                	if( $st['id']=='3' || $st['id']=='8' || $st['id']=='11' || $st['id']=='5' ){ 
                               ?> 
                            <option value="<?php echo $st['id'];?>" <?php echo (($st['id']==$lead_status)?"selected":""); ?> ids="<?php echo $st['id'];?>"><?php echo $st['status'];?></option>
                        <?php } } ?>
                    
                </select>
             </div>
           </div>
           
            
          <div class="col-md-12" id="lost_id" style="display:none" >
            <div class="form-group ">
                <label for="">lost sale Reason</label>
                
                <input type="text" class="form-control" id="lost" name="lost_sale_detail" value="<?php echo $leads['lost_sale_detail']; ?> " placeholder="Enter lost sale" >
                <div class="invalid-feedback"></div>
            </div>          
          </div>
           
         </div>
         
         
         
         
         
         <!-- other fileds end  -->
         
         
          <div class="text-right">
              <button type="submit" class="btn btn-success waves-effect waves-light" value="upload" id="save_">Update</button>
              <button type="button" class="btn btn-danger waves-effect waves-light m-l-10" onclick="Custombox.modal.close();">Cancel</button>
          </div>
         
              <?php echo form_close(); ?>
          

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
      
</div>
</div>
      <link href="<?php echo base_url();?>assets/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/libs/clockpicker/bootstrap-clockpicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/libs/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
         <script src="<?php echo base_url();?>assets/js/vendor.min.js"></script>
   <!-- Plugins js-->
        <script src="<?php echo base_url();?>assets/libs/flatpickr/flatpickr.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/pages/form-pickers.init.js"></script>

        