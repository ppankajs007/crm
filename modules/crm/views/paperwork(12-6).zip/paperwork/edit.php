  <style>
  	.error {
    display: none;
    width: 100%;
    margin-top: .25rem;
    font-size: .75rem;
    color: #f1556c;
    display: block;
}
  </style>
        
    <div class="content-pageee">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">UBold</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                                            <li class="breadcrumb-item active">Advanced</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Edit Paperwork Lead</h4>
                                </div>
                            </div>
                        </div>  
                          <div class="row">
                            <div class="col-12">   
                                 <div class="card">
                                  <div class="card-body">

  <?php 
  //print_r($leads);
 
             if( empty($leads) ) return;
                extract($leads);
              $fullname= @$first_name.''.@$last_name;  


               ?>
         
        <?php $attr = array( 'id' => 'pweditform'); echo form_open($this->uri->uri_string(),$attr); ?>
        <div class="row">
          <div class="col-12">
            <div class="form-group ">
                <label for="">Full Name</label>
                 <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
                <input type="text" class="form-control" name="name" value="<?php echo $fullname;?>" placeholder="Enter full name" >
                <div class="invalid-feedback"></div>
            </div>          
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="form-group">
                <label for="">Measurement Method</label>
                <select  class="form-control" id="pw_mmethod" name="pw_mmethod" data-toggle="select2">
                    <option value="">Select Option</option><?php if($pw_mmethod == 'Guide'){ echo 'selected';} ?>
                    <option value="Diagram" <?php if($pw_mmethod == 'Diagram'){ echo 'selected';} ?> >Diagram</option>
                    <option value="Guide"<?php if($pw_mmethod == 'Guide'){ echo 'selected';} ?>>Guide</option>
                    <option value="Field Measurement"<?php if($pw_mmethod == 'Field Measurement'){ echo 'selected';} ?>>Field Measurement</option>
                   
                </select>
             </div>
           </div>
      </div>
        <div class="row">
            <div class="col-12">
              <div class="form-group">
                <label for="">Field Measure Required</label>
                <select  class="form-control" id="pw_fmreq" name="pw_fmreq" data-toggle="select2">
                    <option value="">Select Option</option>
                    <option value="Yes"<?php if($pw_fmreq == 'Yes'){ echo 'selected';} ?>>Yes</option>
                    <option value="No"<?php if($pw_fmreq == 'No'){ echo 'selected';} ?>>No</option>
                </select>
              </div>
          </div>
        </div>
               
         <div class="row">  
          <div class="col-12">     
               <div class="form-group">
                  <label for="">F/M Date</label>
                  <input type="text" class="form-control" value="<?php echo $pw_fmdate;?>" name="pw_fmdate"  id="pw_fmdate" >
              </div>
          </div>
        </div>
            <!-- <div class="row"> -->
         <div class="row">
           <div class="col-12">
              <div class="form-group">
                    <label for="">F/M Time</label>
                  <input type="text" class="form-control" name="pw_fmtime" value="<?php echo $pw_fmtime;?>" id="pw_fmtime" >
              </div> 
           </div>
         </div> 
          <div class="row">
            <div class="col-12">
             <div class="form-group">
                <label for="">F/M Person</label>
                <input type="text" class="form-control" name="pw_fmperson" value="<?php echo $pw_fmperson;?>" id="pw_fmperson" >
             </div>  
           </div>
         </div> 
          <div class="row">
            <div class="col-12">
             <div class="form-group">
                <label for="">Next Step</label>
                <select class="form-control" name="action_lead" data-toggle="select2"> 
                       <?php if(!empty($action_lead)){?>
                       
                        <option value="<?php echo $action_lead;?>"><?php echo $action_lead;?></option>
                           
                      <?php }else{?>
                         <option value="Select option" id="0">Select option</option>
                         
                         <?php }?>
                         
                           <option value="Task">Task</option>
                                   <option value="Appointment">Appointment</option>
                              <optgroup label="You">
                                  <option value="You Called">You Called</option>
                                   <option value="You Emailed">You Emailed</option>
                                   <option value="You Left Voicemail">You Left Voicemail</option>
                                   <option value="You Fixed">You Fixed</option>
                                   <option value="You Create Layout">You Create Layout</option>
                                   <option value="You Create Pricing">You Create Pricing</option>
                                    <option value="You Survey">You Survey</option>
                                     </optgroup>
                                        <optgroup label="Customer">
                                    <option value="Customer Called">Customer Called</option>
                                  <option value="Customer Emailed">Customer Emailed</option>
                              <option value="Customer Left Voicemail">Customer Left Voicemail</option>
                           <option value="Customer Faxed">Customer Faxed</option>
                           <option value="Customer Visited">Customer Visited</option>
                           <option value="Customer submitted layout">Customer submitted layout</option>
                      </optgroup>
                        </select>
             </div>
           </div>
         </div> 
        <div class="row">
            <div class="col-12">
                <?php
                if(!empty($reminder_date)){
                    
                $timestamp = strtotime( $reminder_date); 
                 $rem = date('m-d-Y', $timestamp);
                }else{
                   $rem="NA"; 
                    
                }
                
                ?>
                <div class="form-group">
                  <label for="">Next Step Date</label>
                  <input type="text" class="form-control" name="reminder_date" value="<?php echo $rem;?>" id="basic-datepicker" >
                </div>
            </div>
        </div> 

         <div class="row">
           <div class="col-12">
                     <div class="form-group">
                        <label for="">N/S Owner</label>
                         <select class="form-control" name="assigned_to" > 
                         <option value="Select option" id="0">Select option</option>
                        	<?php 
                          foreach ($users as $us)
                        {
                         ?> 
                                <option value="<?php echo $us['id'];?>" <?php echo (($us['id']==$assigned_to)?"selected":""); ?> id="0"><?php echo $us['name'];?></option>
                                <?php }?>
                                </select>
                    </div>
              </div>
         </div> 
         

         <div class="row">
              <div class="col-12"> 
                   <div class="form-group">
                        <label for="position">Status</label>
                         <select class="form-control" name="lead_status"  data-toggle="select2"> 
                        <!--<option value="Select option" id="0">Select option</option>-->
                       <?php 
                         foreach ($lead_statuss as $st) {
                                	if( $st['id']=='3' || $st['id']=='5' ){ 
                               ?> 
                            <option value="<?php echo $st['id'];?>" <?php echo (($st['id']==$lead_status)?"selected":""); ?> id="0"><?php echo $st['status'];?></option>
                        <?php } } ?>
                  </select>
             </div>
        </div>
      </div>
                                 
          <div class="text-right">
              <button type="submit" class="btn btn-success waves-effect waves-light" value="upload" id="save_">Update</button>
              <button type="button" class="btn btn-danger waves-effect waves-light m-l-10" onclick="Custombox.modal.close();">Cancel</button>
          </div>
         
              <?php echo form_close(); ?>
          

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
      
</div>
</div>
      <link href="<?php echo base_url();?>assets/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/libs/clockpicker/bootstrap-clockpicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/libs/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
         <script src="<?php echo base_url();?>assets/js/vendor.min.js"></script>
   <!-- Plugins js-->
        <script src="<?php echo base_url();?>assets/libs/flatpickr/flatpickr.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="<?php echo base_url();?>assets/libs/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/pages/form-pickers.init.js"></script>

        