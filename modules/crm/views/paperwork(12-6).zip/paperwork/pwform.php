  <style>
    .error {
    display: none;
    width: 100%;
    margin-top: .25rem;
    font-size: .75rem;
    color: #f1556c;
    display: block;
}
  </style>
        
    <div class="content-pageee">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="<?php echo base_url();?>crm/PWleads">Back</a></li>
                                            <!--<li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>-->
                                            <!--<li class="breadcrumb-item active">Advanced</li>-->
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Add Paperwork pending</h4>
                                </div>
                            </div>
                        </div>  
                          <div class="row">
                            <div class="col-12">   
                                 <div class="card">
                                  <div class="card-body">

  <?php 
 
             // if( empty($leads) ) return;;
             //    extract($leads);
             //   $name1= @$first_name.' '.@$last_name; 
             //   $na= trim($name1);


               ?>
         
              <!--   <form method="post" action="<?php// echo base_url();?><?php// echo base_url();?>index.php/crm/leads/edit_leads/<?php //echo $id;?>"> -->
              
              
                    <?php $attr = array( 'id' => 'edit_form'); echo form_open($this->uri->uri_string(),$attr); ?>
                    
                     <h5 class="page-title">Product Information</h5>
                     <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Cabinet Manufacturer</label>
                     <select class="form-control" name="cabinet_manufacturer"  data-toggle="select2"> 
                     <option value="">Select Option</option>
                      <option value="Forevermark">Forevermark</option>
                      <option value="CNC Cabinetry">CNC Cabinetry</option>
                      <option value="J&K Cabinetry">J&K Cabinetry</option>
                      <option value="Wolf">Wolf</option>
                       <option value="Hanssem">Hanssem</option>
                        <option value="WoodMaster">WoodMaster</option>
                         <option value="Legacy Crafted">Legacy Crafted</option>
                          <option value="Holiday Kitchens">Holiday Kitchens</option>
                    </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Door Style</label>
                        <input type="text" class="form-control" name="door_style" value="" id="" placeholder="Enter Door Style" >
                    </div>
                </div></div>
                    <div class=row>
                    <div class="col-6">
                    <div class="form-group">
                        <label for="position">Desired Flooring Type</label>
                        <input type="text" class="form-control phone" name="desired_flooring_type" value=""  id="phone" placeholder="Enter Desired Flooring Type">
                    </div>
                </div>
                <div class="col-6">
                     <div class="form-group">
                        <label for="position">Desired Flooring Color</label>

                        <input type="text" class="form-control" name="desired_flooring_color" value="" id="position" placeholder="Enter Desired Flooring Color">
                    </div>
                </div>
            </div>
           <div class=row>
                    <div class="col-6">
             <div class="form-group">
                        <label for="position">Backsplash</label>
                        <input type="text" class="form-control" name="backsplash" value="" id="position" placeholder="Enter Backsplash ">
                    </div>
                 </div>
                  
                  <div class="col-6">
                    <div class="form-group">
                        <label for="position">Countertop Type</label>
                  <select class="form-control" name="countertop_type"  data-toggle="select2">
                      <option value="">Select Option</option>
                      <option value="Quartz">Quartz</option>
                      <option value="Granite">Granite</option>
                      <option value="Soapstone">Soapstone</option>
                      <option value="Marble">Marble</option>
                       <option value="Travertine">Travertine</option>
                        <option value="Formica">Formica</option>
                         <option value="Unsure">Unsure</option>
                         
                    </select> 
                    </div>
                    </div>
                    </div>
               
                     <div class=row>
                    <div class="col-6">
                     <div class="form-group">
                        <label for="position">Countertop Color</label>
                     <input type="text" class="form-control" name="countertop_color" value="" id="position" placeholder="Enter Countertop Color">
                    </div>
                </div>
                 <div class="col-6">
            
                 
                    <div class="form-group">
                        <label for="position">Knobs and Handles</label>
                       <input type="text" class="form-control" name="knobs_and_handles" value="" id="position" placeholder="Enter Knobs and Handles">
  </div>
                </div>
            </div>

        

   <div class="form-group">

                        <label for="position">Sink Type</label>
                      <!-- <input type="text" class="form-control" id="position" placeholder="Lost Sale Detail"> -->
                          
                  <select class="form-control" name="sink_type"  data-toggle="select2"> 
                  <option value="">Select Option</option>
                      <option value="Undermount Stainless Steel">Undermount Stainless Steel</option>
                      <option value="Undermount Quartz">Undermount Quartz</option>
                      <option value="Stainless Steel Apron Front">Stainless Steel Apron Front</option>
                      <option value="Farmhouse">Farmhouse</option>
                      Farmhouse
                    
                         
                    </select> 
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                       <div class="form-group inline">
                         <label for="position">Sink Color</label>
                  <select class="form-control" name="sink_color"  data-toggle="select2"> 
                  <option value="">Select Option</option>
                      <option value="Stainless Steel">Stainless Steel</option>
                      <option value="White">White</option>
                      <option value="Black">Black</option>
                      <option value="Grey">Grey</option>
                    
                         
                    </select> 

                </div>
              </div>



                <div class="col-md-6">
                     
                <div class="form-group">
                        <label for="position">Sink Bowls</label>
                       <select class="form-control" name="sink_bowls"  data-toggle="select2"> 
                       <option value="">Select Option</option>
                      <option value="One Bowl">One Bowl</option>
                      <option value="Two Bowls">Two Bowls</option>
                     
                    
                         
                    </select> 
                    </div>
              </div>
            </div>
            
            <h5 class="page-title">Appliance Dimensions and Selection</h5>
            <div class="row">
               <div class="col-md-6">
                 <div class="form-group">
                                        <label>Keeping Existing</label>
                                 <input type="text" class="form-control" name="keeping_existing" value="" id="position" placeholder="Enter Keeping Existing">
                                    </div>
                                  </div>
                                  <!-- <input type="text" id="basic-datepicker" class="form-control" placeholder="Basic datepicker"> -->
                           <div class="col-md-6">
                    <div class="form-group">

                        <label for="position">Dishwasher Size</label>
                       <select class="form-control" name="dishwasher_size"  data-toggle="select2">
                           <option value="">Select Option</option> 
                      <option value="24">24</option>
                      <option value="18">18</option>
                     
                    
                         
                    </select> 
                    </div>
                </div>
              </div>


               <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Desired Dishwasher Color</label>
                     <select class="form-control" name="desired_dishwasher_color"  data-toggle="select2">
                         <option value="">Select Option</option> 
                      <option value="Stainless Steel">Stainless Steel</option>
                      <option value="White">White</option>
                      <option value="JBlack">Black</option>
                      <option value="Matching Front">Matching Front</option>
                      
                    </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Dishwasher Quantity</label>
                              <select class="form-control" name="dishwasher_quantity"  data-toggle="select2"> 
                   <option value="">Select Option</option>
                    <option value="0">0</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                    
                      
                    </select> 
                    </div>
                </div></div>



                 <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Range Size</label>
                     <select class="form-control" name="range_size"  data-toggle="select2"> 
                     <option value="">Select Option</option>
                      <option value="N/A">N/A</option>
                      <option value="30">30</option>
                      <option value="36">36</option>
                      <option value="48">48</option>
                      
                    </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Cooktop Size</label>
                             <select class="form-control" name="cooktop_size_p"  data-toggle="select2"> 
                             <option value="">Select Option</option>
                      <option value="N/A">N/A</option>
                      <option value="24">24</option>
                      <option value="30">30</option>
                      <option value="36">36</option>
                       <option value="42">42</option>
                        <option value="45">45</option>
                         <option value="48">48</option>
                         <option value="60">60</option>
                    
                      
                    </select> 
                    </div>
                </div></div>



                 <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Wall Oven Count</label>
                     <select class="form-control" name="wall_oven_count"  data-toggle="select2"> 
                     <option value="">Select Option</option>
                      <option value="N/A">N/A</option>
                      <option value="Single Wall Oven">Single Wall Oven</option>
                       <option value="Double Wall Oven">Double Wall Oven</option>
                      
                      <option value="Wall Oven/Microwave Combo">Wall Oven/Microwave Combo</option>
                     
                      
                    </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Wall Oven Width</label>
                              <select class="form-control" name="wall_oven_width"  data-toggle="select2"> 
                              <option value="">Select Option</option>
                      <option value="N/A">N/A</option>
                      <option value="24">24</option>
                      <option value="27">27</option>
                      <option value="30">30</option>
                      
                    </select> 
                    </div>
                </div></div>


                 <div class=row>
                    <div class="col-6">
                    <!--<div class="form-group ">-->
                    <!--    <label for="name">Wall Oven Count</label>-->
                    <!-- <select class="form-control" name="lead_status"  data-toggle="select2"> -->
                    <!-- <option value="Yes">Select Option</option>-->
                    <!--  <option value="N/A">N/A</option>-->
                    <!--  <option value="30">30</option>-->
                    <!--  <option value="36">36</option>-->
                    <!--  <option value="48">48</option>-->
                      
                    <!--</select> -->
                    <!--    <div class="invalid-feedback"></div>-->
                    <!--</div>-->
                     
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Cooktop Size</label>
                              <select class="form-control" name="cooktop_size"  data-toggle="select2"> 
                              <option value="">Select Option</option>
                      <option value="N/A">N/A</option>
                      <option value="24">24</option>
                      <option value="30">30</option>
                      <option value="36">36</option>
                       <option value="42">42</option>
                        <option value="45">45</option>
                         <option value="48">48</option>
                         <option value="60">60</option>
                    
                      
                    </select> 
                    </div>
                </div></div>

                 <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Microwave</label>
                     <select class="form-control" name="microwave"  data-toggle="select2">
                         <option value="">Select Option</option> 
                      <option value="N/A">N/A</option>
                      <option value="Above Range">Above Range</option>
                      <option value="In Base Cabinet">In Base Cabinet</option>
                      <option value="On Shelf">On Shelf</option>
                       <option value="On Counter">On Counter</option>
                        <option value="Hanging on Wall">Hanging on Wall</option>
                         <!--<option value="On Shelf">On Shelf</option>-->
                      
                    </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Microwave Width</label>
                              <select class="form-control" name="microwave_width"  data-toggle="select2"> 
                              <option value="">Select Option</option>
                      <option value="N/A">N/A</option>
                      <option value="24">24</option>
                      <option value="30">30</option>
                       </select> 
                    </div>
                </div></div>


                  <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Hood</label>
                     <select class="form-control" name="hood"  data-toggle="select2">
                         <option value="">Select Option</option> 
                      <option value="N/A">N/A</option>
                      <option value="Microwave Hood">Microwave Hood</option>
                      <option value="Stainless Steel Hood">Stainless Steel Hood</option>
                      <option value="Wood Hood">Wood Hood</option>
                       
                    </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Refrigerator Width</label>
                              <select class="form-control" name="refrigerator_width"  data-toggle="select2"> 
                              <option value="">Select Option</option>
                      <option value="N/A">N/A</option>
                      <option value="24">24</option>
                       <option value="30">30</option>
                      <option value="33">33</option>
                       <option value="36">36</option>
                       </select> 

                    </div>
                </div></div>


                  <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Refrigerator Depth</label>
                    <select class="form-control" name="refrigerator_depth"  data-toggle="select2"> 
                    <option value="">Select Option</option>
                      <option value="N/A">N/A</option>
                      <option value="Full Depth">Full Depth</option>
                      <option value="Countertop Depth">Countertop Depth</option>
                     
                       </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Applicance Other</label>
                             <input type="text" class="form-control" name="applicance_other" value="" id="position" placeholder="Enter Applicance Other">

                    </div>
                </div></div>
                
                 <h5 class="page-title">Cabinetry Options</h5>

                 <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Crown Molding</label>
                     <select class="form-control" name="crown_molding"  data-toggle="select2"> 
                     <option value="">Select Option</option>
                      <option value="No Crown">No Crown</option>
                      <option value="Single Stack">Single Stack</option>
                      <option value="Double Stack">Double Stack</option>
                     
                     
                       </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Crown Molding Touch Ceiling</label>
                             <select class="form-control" name="crown_molding_touch_ceiling"  data-toggle="select2"> 
                             <option value="">Select Option</option>
                              <option value="N/A">N/A</option>
                      <option value="Yes">Yes</option>
                      <option value="no">No</option>
                     
                     
                       </select> 

                    </div>
                </div></div>


                 <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Light Rail</label>
                     <select class="form-control" name="light_rail"  data-toggle="select2"> 
                     <option value="">Select Option</option>
                      <option value="Yes">Yes</option>
                      <option value="no">No</option>
                     
                     
                       </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Cabinet Wall Height</label>
                             <select class="form-control" name="cabinet_wall_height"  data-toggle="select2"> 
                             <option value="">Select Option</option>
                      <option value="30">30</option>
                      <option value="36">36</option>
                       <option value="42">42</option>

                     
                       </select> 

                    </div>
                </div></div>

                 <div class=row>
                    <div class="col-12">
                    <div class="form-group ">
                        <label for="name">Option Request (Select with Check Boxes)</label>
                     <select class="form-control" name="option_request"  data-toggle="select2"> 
                     <option value="">Select Option</option>
                      <option value="Roll Out Trays">Roll Out Trays</option>
                      <option value="In Cabinet Trash">In Cabinet Trash</option>
                      
                       <option value="Pantry">Pantry</option>
                       <option value="Spice Racks">Spice Racks</option>
                        <option value="Glass">Glass</option>
                         <option value="Lazy Susan Wall">Lazy Susan Wall</option>
                          <option value="Lazy Susan Base">Lazy Susan Base</option>
                     
                     
                       </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <!-- <div class="form-group">
                        <label for="exampleInputEmail1">Cabinet Wall Height</label>
                             <select class="form-control" name="lead_status"  data-toggle="select2"> 
                      <option value="30">30</option>
                      <option value="36">36</option>
                       <option value="42">42</option>
                       
                     
                       </select> 

                    </div> -->
                </div></div>

        <h5 class="page-title"> Construction Questions</h5>
              <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Ceiling Height</label>
                    <input type="text" class="form-control" name="ceiling_height" value="" id="position" placeholder="Enter Ceiling Height"> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Soffit</label>
                             <select class="form-control" name="soffit"  data-toggle="select2"> 
                             <option value="">Select Option</option>
                      <option value="Yes">Yes</option>
                      <option value="no">No</option>
                     
                     
                       </select> 

                    </div>
                </div></div>


                <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">If Soffit Yes, Keeping?</label>
                    <select class="form-control" name="soffit_yes_keeping"  data-toggle="select2"> 
                    <option value="">Select Option</option>
                      <option value="Yes">Yes</option>
                      <option value="no">No</option>
                       <option value="Not Sure">Not Sure</option>
                     
                     
                       </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Can any walls be moved?</label>
                              <select class="form-control" name="walls_be_moved"  data-toggle="select2"> 
                              <option value="">Select Option</option>
                      <option value="Yes">Yes</option>
                      <option value="no">No</option>
                       <option value="Not Sure">Not Sure</option>
                     
                     
                       </select> 

                    </div>
                </div></div>


                 <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Can Windows or Doors be Moved</label>
                    <select class="form-control" name="doors_be_moved"  data-toggle="select2">
                        <option value="">Select Option</option> 
                      <option value="Yes">Yes</option>
                      <option value="no">No</option>
                       <option value="Not Sure">Not Sure</option>
                     
                     
                       </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Can Plumbing Be Moved</label>
                              <select class="form-control" name="plumbing_be_moved"  data-toggle="select2">
                                  <option value="">Select Option</option> 
                      <option value="Yes">Yes</option>
                      <option value="no">No</option>
                       <option value="Not Sure">Not Sure</option>
                     
                     
                       </select> 

                    </div>
                </div></div>


                  <div class=row>
                    <div class="col-6">
                    <div class="form-group ">
                        <label for="name">Can Hood/Range Location be Moved</label>
                    <select class="form-control" name="range_location_be_moved"  data-toggle="select2">
                        <option value="">Select Option</option> 
                      <option value="Yes">Yes</option>
                      <option value="no">No</option>
                       <option value="Not Sure">Not Sure</option>
                     
                     
                       </select> 
                        <div class="invalid-feedback"></div>
                    </div>
                     
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Can Refrigerator Location be Moved</label>
                              <select class="form-control" name="refrigerator_location_be_moved"  data-toggle="select2"> 
                              <option value="">Select Option</option>
                      <option value="Yes">Yes</option>
                      <option value="no">No</option>
                       <option value="Not Sure">Not Sure</option>
                     
                     
                       </select> 

                    </div>
                </div></div>
             
                       
                  

                    <div class="text-right">
            <button type="submit" class="btn btn-success waves-effect waves-light" value="upload" id="save_">Save</button>
            <button type="button" class="btn btn-danger waves-effect waves-light m-l-10" onclick="Custombox.modal.close();">Cancel</button>
        </div>
                  </form>
              </div>
              <?php echo form_close(); ?>
          </div>
      
            </div>
      
</div></div>
      
        